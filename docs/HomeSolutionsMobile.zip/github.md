repo: fedehanselmann18/homesolutions
branch: main
path: frontend/src

## Last sync
date: 2026-08-26T20:22:41Z

### Updated in this project
- Recreación fiel de Login, Panel y Fases del proyecto (desktop) desde el código.
- Versión mobile 390px de las tres pantallas: tab bar inferior, cards por fila, KPIs apilados.
- Sheet nativo de carga de comprobante (cámara / galería / PDF) para mobile.
- Turno 2: Acciones (libro de obra) y detalle de compra en mobile + desktop.

## Screen map
| Pantalla del proyecto | Archivos del repo |
|---|---|
| 1a Login (mobile + desktop) | pages/Login.jsx, pages/Auth.css, index.css |
| 1b Panel (mobile + desktop) | pages/Dashboard.jsx, pages/Dashboard.css, components/proyectos/TablaProyectos.jsx/.css, components/shared/TarjetaKpi.jsx/.css, components/shared/PageHeader.jsx/.css, components/shared/FiltrosSegmentados.jsx/.css, components/Sidebar.jsx/.css, layouts/MainLayout.css |
| 2a Acciones / Movimientos (mobile + desktop) | components/proyectos/Acciones.jsx/.css, components/proyectos/LibroDeObra.css, components/shared/FiltrosSegmentados.jsx/.css, constants/tipoMovimiento.js, constants/estadoCompra.js |
| 2b Detalle de compra (mobile + desktop) | components/modals/ModalDetalleCompra.jsx, components/modals/ModalDetalle.css, components/modals/modal-base.css |
| 1c Fases del proyecto (mobile + desktop) | components/proyectos/Fases.jsx/.css, components/proyectos/ProyectoDetalleHeader.jsx/.css, pages/ProyectoDetalle.jsx, components/shared/Tabs.jsx/.css, components/shared/Breadcrumbs.css, components/shared/ComprobantesUploader.jsx/.css, constants/estados.js, constants/colores.js |
